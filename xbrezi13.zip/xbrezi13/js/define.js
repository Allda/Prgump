var FLOOR = 0;
var WATER = 1;
var GRASS = 2;
var LAVA = 3;
var CRATE = 4;
var STONE = 5;
var SNOW = 6;
var EMPTY = 9;
