# PRGump
**PRGump** is WEB-GL game which use framework [Three.js](http://threejs.org/).

![alt tag](https://github.com/Allda/Prgump/blob/master/img/screenshot.png)


### Build
```
cd Pgrump
npm install
grunt download // this step is only for lightweight version
grunt build
open index.html in browser
```

## Supported browsers
* Firefox
* Chrome
